/*:
 # EMOJICATCH
 Welcome to EmojiCatch!
 
 Catch the smiley faces in midair by tapping them with your finger before they drop to the ground to get points, but let frowny faces drop to the ground. Be careful not to click on a frowny face, and do not let a smiley face fall to the ground or it's game over!
 # Emoji Key:
 😀 = 1 point
 🤩 = 5 points
 ☹️ = Game Over
 
 Note:
 You should run this playground in landscape mode, at 50% volume.
 */

import UIKit
import AVFoundation
import PlaygroundSupport
class controller: UIViewController {
    var gravity: UIGravityBehavior!
    var animator: UIDynamicAnimator!
    var collision: UICollisionBehavior!
    var xAnchor: NSLayoutConstraint?
    var yAnchor: NSLayoutConstraint?
    var soundtrack: AVAudioPlayer?
    var buttonSoundEffect: AVAudioPlayer?
    let randomXValue = Int.random(in: 0...900)
    let randomX2Value = Int.random(in: 0...900)
    let button = UIButton()
    let playTitle = UILabel()
    let button2 = UIButton()
    let emoji1 = UILabel()
    let emoji2 = UILabel()
    override func viewDidLoad(){
        super.viewDidLoad()
        view.backgroundColor = .white
        startSoundtrack()
        playTitleSetup()
        buttonSetup()
        setupEmoji1()
        setupEmoji2()
        animateEmojis()
    }
    func setupEmoji1() {
        emoji1.frame = CGRect(x: randomXValue, y: 0, width: 50, height: 50)
        emoji1.text = "😀"
        emoji1.textColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        emoji1.font = UIFont(name: "Helvetica", size: 50)
        view.addSubview(emoji1)
    }
    func setupEmoji2() {
        emoji2.frame = CGRect(x: randomX2Value, y: 0, width: 50, height: 50)
        emoji2.text = "☹️"
        emoji2.textColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        emoji2.font = UIFont(name: "Helvetica", size: 50)
        view.addSubview(emoji2)
    }
    func animateEmojis() {
        animator = UIDynamicAnimator(referenceView: view)
        gravity = UIGravityBehavior(items: [emoji1, emoji2])
        gravity.magnitude = 1
        animator.addBehavior(gravity)
        collision = UICollisionBehavior(items: [emoji1, emoji2])
        collision.translatesReferenceBoundsIntoBoundary = true
        animator.addBehavior(collision)
    }
    func startSoundtrack() {
        let path = Bundle.main.path(forResource: "My Song 2.m4a", ofType: nil)!
        let url = URL(fileURLWithPath: path)
        do {
            soundtrack = try AVAudioPlayer(contentsOf: url)
            soundtrack?.play()
        } catch {
            
        }
    }
    func soundEffect1() {
        let path = Bundle.main.path(forResource: "My Song 3.m4a", ofType: nil)!
        let url = URL(fileURLWithPath: path)
        do {
            buttonSoundEffect = try AVAudioPlayer(contentsOf: url)
            buttonSoundEffect?.play()
        } catch {
            
        }
    }
    
    func buttonSetup() {
        button2.setTitleColor(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0), for: .normal)
        button2.setTitle("Start Game", for: .normal)
        button2.addTarget(self, action: #selector(onButtonPress), for: .touchUpInside)
        button2.backgroundColor = #colorLiteral(red: 0.34117648005485535, green: 0.6235294342041016, blue: 0.16862745583057404, alpha: 1.0)
        button2.layer.cornerRadius = 25
        view.addSubview(button2)
        addButton2Constraints()
    }
    func addButton2Constraints() {
        button2.translatesAutoresizingMaskIntoConstraints = false
        button2.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        button2.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 100).isActive = true
        button2.heightAnchor.constraint(equalToConstant: 50).isActive = true
        button2.widthAnchor.constraint(equalToConstant: 150).isActive = true
    }
    func playTitleSetup() {
        playTitle.text = "E m o j i C a t c h"
        playTitle.textColor = #colorLiteral(red: 0.21960784494876862, green: 0.007843137718737125, blue: 0.8549019694328308, alpha: 1.0)
        playTitle.font = UIFont(name: "GillSans-Bold", size: 75.0)
        view.addSubview(playTitle)
        addPlayTitleConstraints()

    }
    func addPlayTitleConstraints() {
        playTitle.translatesAutoresizingMaskIntoConstraints = false
        playTitle.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        playTitle.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -100).isActive = true
        playTitle.heightAnchor.constraint(equalToConstant: 100).isActive = true
    }
    @objc func onButtonPress() {
        soundtrack?.stop()
        self.navigationController?.pushViewController(gameController(), animated: false)
    }
    func buttonConstraints(){
        button.translatesAutoresizingMaskIntoConstraints = false
        button.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        button.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        button.heightAnchor.constraint(equalToConstant: 50).isActive = true
        button.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
    }
}

class gameController: UIViewController, UICollisionBehaviorDelegate {
    let number = Int.random(in: 0...900)
    let number2 = Int.random(in: 0...900)
    let number3 = Int.random(in: 0...900)
    let number4 = Int.random(in: 0...900)
    let number5 = Int.random(in: 0...900)
    let number6 = Int.random(in: 0...900)
    let number7 = Int.random(in: 0...900)
    let number8 = Int.random(in: 0...900)
    let number9 = Int.random(in: 0...900)
    let number10 = Int.random(in: 0...900)
    var hasBeenClicked = false
    var bounce: UIDynamicItemBehavior!
    var gameOverSound: AVAudioPlayer?
    var gameMusic: AVAudioPlayer?
    var score = 0
    let scoreLabel = UILabel()
    let emojis = ["😀","☹️", "😀", "🤩", "☹️"]
    let emojiButton = UIButton()
    let endView = UIView()
    let gameTitle = UILabel()
    let restartButton = UIButton()
    let yourScore = UILabel()
    var gameOverHasHappened = false
    var gravity: UIGravityBehavior!
    var animator: UIDynamicAnimator!
    var collision: UICollisionBehavior!
    override func viewDidLoad() {
        view.backgroundColor = .white
        self.navigationItem.hidesBackButton = true
        startGameSoundtrack()
        setupScore()
        setupEmoji()
        collision.collisionDelegate = self
    }
    func startGameSoundtrack() {
        let path = Bundle.main.path(forResource: "GameSoundtrack.m4a", ofType: nil)!
        let url = URL(fileURLWithPath: path)
        do {
            gameMusic = try AVAudioPlayer(contentsOf: url)
            gameMusic?.play()
        } catch {
            
        }
    }
    func collisionBehavior(_ behavior: UICollisionBehavior, beganContactFor item: UIDynamicItem, withBoundaryIdentifier identifier: NSCopying?, at p: CGPoint) {
        if emojiButton.currentTitle == "☹️" && hasBeenClicked == false {
            emojiButton.removeFromSuperview()
            setupEmoji()
            collision.collisionDelegate = self
        } else if (emojiButton.currentTitle == "😀" || emojiButton.currentTitle == "🤩") && gameOverHasHappened == false {
            gameOverHasHappened = true
            emojiButton.removeFromSuperview()
            scoreLabel.removeFromSuperview()
            gameMusic?.stop()
            playGameOverSound()
            setupEndView()
            titleSetup()
            buttonSetup()
            yourScoreSetup()
        }
    }
    func animateEmoji() {
        animator = UIDynamicAnimator(referenceView: view)
        gravity = UIGravityBehavior(items: [emojiButton])
        gravity.magnitude = 1.5
        bounce = UIDynamicItemBehavior(items:[emojiButton])
        bounce.elasticity = 0
        animator?.addBehavior(bounce)
        animator?.addBehavior(gravity)
        collision = UICollisionBehavior(items: [emojiButton])
        collision.translatesReferenceBoundsIntoBoundary = true
        animator?.addBehavior(collision)
    }
    func setupScore() {
        scoreLabel.text = "Score: \(score)"
        scoreLabel.textColor = #colorLiteral(red: 0.27450981736183167, green: 0.48627451062202454, blue: 0.1411764770746231, alpha: 1.0)
        view.addSubview(scoreLabel)
        setupScoreLabelConstraints()

    }
    func setupScoreLabelConstraints() {
        scoreLabel.translatesAutoresizingMaskIntoConstraints = false
        scoreLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10).isActive = true
        scoreLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -200).isActive = true
        scoreLabel.heightAnchor.constraint(equalToConstant: 50).isActive = true
        scoreLabel.widthAnchor.constraint(equalToConstant: 100).isActive = true
    }
    func setupEmoji() {
            emojiButton.frame = CGRect(x: number, y: 1, width: 50, height: 50)
        emojiButton.setTitle("\(emojis.randomElement()!)", for: .normal)
        emojiButton.titleLabel?.font = UIFont(name: "Helvetica", size: 50)
        emojiButton.setTitleColor(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0), for: .normal)
        emojiButton.addTarget(self, action: #selector(onEmojiPress), for: .touchDown)
        view.addSubview(emojiButton)
        animateEmoji()
    }
    @objc func onEmojiPress() {
        if emojiButton.currentTitle == "😀" {
            emojiButton.removeFromSuperview()
            emojiButton.setNeedsDisplay()
            score += 1
            scoreLabel.text = "Score: \(score)"
            scoreLabel.setNeedsDisplay()
            setupEmoji()
            collision.collisionDelegate = self
        } else if emojiButton.currentTitle == "☹️" {
            hasBeenClicked = true
            emojiButton.removeFromSuperview()
            playGameOverSound()
            setupEndView()
            titleSetup()
            buttonSetup()
            scoreLabel.removeFromSuperview()
            yourScoreSetup()
            gameMusic?.stop()
            collision.collisionDelegate = self
        } else if emojiButton.currentTitle == "🤩" {
            emojiButton.removeFromSuperview()
            emojiButton.setNeedsDisplay()
            score += 5
            scoreLabel.text = "Score: \(score)"
            scoreLabel.setNeedsDisplay()
            setupEmoji()
            collision.collisionDelegate = self
        }
    }
    
    func randomEmoji() -> String {
        return emojis.randomElement()!
    }
    func setupEndView() {
        endView.backgroundColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        endView.layer.cornerRadius = 50
        endView.alpha = 0
        view.addSubview(endView)
        setupEndViewConstraints()
        UIView.animate(withDuration: 2) {
            self.endView.alpha = 1
        }
    }
    func setupEndViewConstraints() {
        endView.translatesAutoresizingMaskIntoConstraints = false
        endView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        endView.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        endView.heightAnchor.constraint(equalToConstant: 300).isActive = true
        endView.widthAnchor.constraint(equalToConstant: 500).isActive = true
    }
    func titleSetup() {
        gameTitle.alpha = 0
        gameTitle.text = "GAME OVER"
        gameTitle.font = UIFont(name: "Optima-BoldItalic", size: 50)
        gameTitle.textColor = .red
        gameTitle.textAlignment = .center
        view.addSubview(gameTitle)
        addTitleConstraints()
        UIView.animate(withDuration: 2) {
            self.gameTitle.alpha = 1
        }
    }
    func addTitleConstraints() {
        gameTitle.translatesAutoresizingMaskIntoConstraints = false
        gameTitle.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        gameTitle.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        gameTitle.widthAnchor.constraint(equalToConstant: 400).isActive = true
        gameTitle.heightAnchor.constraint(equalToConstant: 100).isActive = true
    }
    func yourScoreSetup() {
        yourScore.alpha = 0
        yourScore.text = "Your Score was \(score)"
        yourScore.textColor = .red
        yourScore.font = UIFont(name: "Futura", size: 30)
        yourScore.textAlignment = .center
        view.addSubview(yourScore)
        addYourScoreConstraints()
        UIView.animate(withDuration: 2) {
            self.yourScore.alpha = 1
        }
    }
    func addYourScoreConstraints() {
        yourScore.translatesAutoresizingMaskIntoConstraints = false
        yourScore.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        yourScore.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -100).isActive = true
        yourScore.widthAnchor.constraint(equalToConstant: 400).isActive = true
        yourScore.heightAnchor.constraint(equalToConstant: 100).isActive = true
    }
    func buttonSetup() {
        restartButton.alpha = 0
        restartButton.setTitle("Retry", for: .normal)
        restartButton.setTitleColor(.red, for: .normal)
        restartButton.titleLabel?.font = UIFont(name:"Palatino-BoldItalic", size: 25)
        restartButton.addTarget(self, action: #selector(onRestartButtonPress), for: .touchDown)
        view.addSubview(restartButton)
        addButtonConstraints()
        UIView.animate(withDuration: 2) {
            self.restartButton.alpha = 1
        }
    }
    func addButtonConstraints() {
        restartButton.translatesAutoresizingMaskIntoConstraints = false
        restartButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        restartButton.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 100).isActive = true
        restartButton.widthAnchor.constraint(equalToConstant: 200).isActive = true
        restartButton.heightAnchor.constraint(equalToConstant: 100).isActive = true
    }
    @objc func onRestartButtonPress() {
        self.navigationController?.pushViewController(gameController(), animated: false)
    }
    func playGameOverSound() {
        let path = Bundle.main.path(forResource: "My Song.m4a", ofType: nil)!
        let url = URL(fileURLWithPath: path)
        do {
            gameOverSound = try AVAudioPlayer(contentsOf: url)
            gameOverSound?.play()
        } catch {
            
        }
    }
}
let home = controller()
let navi = UINavigationController(rootViewController: home)
navi.navigationBar.backgroundColor = UIColor.white.withAlphaComponent(100)
PlaygroundPage.current.liveView = navi
